#ifndef EXAMPLEOBJECT_H
#define EXAMPLEOBJECT_H

#include "CGF/CGFobject.h"

class ExampleObject: public CGFobject {
	public:
		void draw();
};

#endif
