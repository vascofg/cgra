#ifndef MYUNITCUBE_H
#define MYUNITCUBE_H

#include "CGF/CGFobject.h"

class myUnitCube: public CGFobject {
	public:
		void draw();
};

#endif
