#ifndef TPSCENE_H
#define TPSCENE_H

#include "CGF/CGFscene.h"

class TPscene : public CGFscene
{
public:
	void init();
	void display();
	void drawTables();
};

#endif
