#ifndef MYFLOOR_H
#define MYFLOOR_H

#include "CGF/CGFobject.h"

class myFloor: public CGFobject {
	public:
		void draw();
};

#endif
