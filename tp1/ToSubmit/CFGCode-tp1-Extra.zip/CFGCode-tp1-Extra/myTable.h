#ifndef MYTABLE_H
#define MYTABLE_H

#include "CGF/CGFobject.h"

class myTable: public CGFobject {
	public:
		void draw();
};

#endif
