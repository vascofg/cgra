#ifndef MYMATERIALS_H
#define MYMATERIALS_H
#include "CGFappearance.h"

// Material for the top of the table
class tableAppearance: public CGFappearance{
	public:
	tableAppearance();

};


// Material for the slides
class slidesAppearance : public CGFappearance{
	public:
	slidesAppearance();

};

// Material for the board
class boardAppearance : public CGFappearance{
	public:
	boardAppearance();

};


#endif
