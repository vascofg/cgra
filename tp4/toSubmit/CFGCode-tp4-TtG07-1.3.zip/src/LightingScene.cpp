#include "LightingScene.h"
#include "CGFaxis.h"
#include "CGFapplication.h"
#include "myUnitCube.h"
#include <math.h>

// Global ambient light (do not confuse with ambient component of individual lights)
float globalAmbientLight[4]= {0,0,0,1.0};

// Constants for materials
#define BOARD_HEIGHT 6.0
#define BOARD_WIDTH 6.4
#define BOARD_A_DIVISIONS 30
#define BOARD_B_DIVISIONS 100

void LightingScene::init() 
{
	// Enables lighting computations
	glEnable(GL_LIGHTING);

	// Sets up some lighting parameters
	// Computes lighting only using the front face normals and materials
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);  
	
	// Define ambient light (do not confuse with ambient component of individual lights)
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globalAmbientLight);  
	
	// Declares and enables lights
	initLights();
	
	// Uncomment below to enable normalization of lighting normal vectors
	glEnable (GL_NORMALIZE);
	
	// Declares objects
	table = new myTable();
	leftWall = new Plane();
	planeWall = new Plane();
	floor= new Plane();
	boardA = new Plane(BOARD_A_DIVISIONS);
	boardB = new Plane(BOARD_B_DIVISIONS);
	
	// Declare Materials
	boardMaterial=new boardAppearance();
	slidesMaterial=new slidesAppearance();

}

void LightingScene::display() 
{

	// ---- BEGIN Background, camera and axis setup
	
	// Clear image and depth buffer everytime we update the scene
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	// Initialize Model-View matrix as identity (no transformation
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glShadeModel(GL_SMOOTH);
	
	// Apply transformations corresponding to the camera position relative to the origin
	CGFscene::activeCamera->applyView();
	// Draw axis
	axis.draw();
	light0->draw();
	lightBoardA->draw();
	lightBoardB->draw();
	// ---- END Background, camera and axis setup

	// ---- BEGIN Primitive drawing section
	
	
	//Left Table
	glPushMatrix();
		glTranslated(5, 0, 8);
		table->draw();
	glPopMatrix();

	//Right Table
	glPushMatrix();
		glTranslated(12, 0, 8);
		table->draw();
	glPopMatrix();

	//Floor
	// Coefficients for material
	float amb[3] = { 0, 0, 0.3984 };
	float dif[3] = { 0, 0, 0.3984 };
	float spec[3] = { 0, 0, 0.1 };
	float shininess = 12.f;
	CGFappearance *materialF = new CGFappearance(amb, dif, spec, shininess);
	materialF->apply();
	glPushMatrix();
		glTranslated(7.5, 0, 7.5);
		glScaled(15, 0.2, 15);
		floor->draw();
	glPopMatrix();
	
	// Left Wall
	float amb1[3] = { 0.3984, 0, 0 };
	float dif1[3] = { 0.3984, 0, 0 };
	float spec1[3] = { 0.20, 0, 0 };
	float shininess1 = 12.f;
	CGFappearance *materialLw = new CGFappearance(amb1, dif1, spec1,shininess1);
	materialLw->apply();
	glPushMatrix();
		glTranslated(0, 4, 7.5);
		glRotated(-90.0, 0, 0, 1);
		glScaled(8, 0.2, 15);
		leftWall->draw();
	glPopMatrix();
	
	//Plane Wall
	glPushMatrix();
		glTranslated(7.5, 4, 0);
		glRotated(90.0, 1, 0, 0);
		glScaled(15, 0.2, 8);
		planeWall->draw();
	glPopMatrix();

	// Slides Board A
	glPushMatrix();
		glTranslated(4, 4, 0.2);
		glScaled(BOARD_WIDTH, BOARD_HEIGHT, 1);
		glRotated(90.0, 1, 0, 0);
		slidesMaterial->apply();
		boardA->draw();
	glPopMatrix();

	//Board B
	glPushMatrix();
		glTranslated(10.5, 4, 0.2);
		glScaled(BOARD_WIDTH, BOARD_HEIGHT, 1);
		glRotated(90.0, 1, 0, 0);
		boardMaterial->apply();
		boardB->drawMaintainRatio(512,372);
	glPopMatrix();
	
	
	// ---- END Primitive drawing section
	

	// We have been drawing in a memory area that is not visible - the back buffer, 
	// while the graphics card is showing the contents of another buffer - the front buffer
	// glutSwapBuffers() will swap pointers so that the back buffer becomes the front buffer and vice-versa
	glutSwapBuffers();
}

LightingScene::~LightingScene() 
{

}

