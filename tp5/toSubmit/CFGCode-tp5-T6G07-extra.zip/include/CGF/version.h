#pragma once

const char CGFVersion[]= "v1.3";
const char CGFId[]= "$Id$";

 