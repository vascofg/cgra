#include "myRobot.h"
#include "myMaterials.h"
#include <iostream>
using namespace std;
myRobot::myRobot(){
    
}

void myRobot::draw(){
    //DRAW THE TRIANGLE
    glBegin(GL_TRIANGLES);
        glVertex3d(0.5, 0.3, 0);
        glVertex3d(-0.5, 0.3, 0);
        glVertex3d(0, 0.3, 2);
    glEnd();
    
}
 void myRobot::update(long milis){

 }